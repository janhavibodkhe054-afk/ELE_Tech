import React from "react";
import ServicesHero from "./section/ServicesHero";
import ServicesOverview from "./section/ServicesOverview";
import ServicesCards from "./section/ServicesCards";

const Services = () => {
  return (
    <>
      <ServicesHero />
      <ServicesCards />
      <ServicesOverview />
      
    </>
  );
};

export default Services;
