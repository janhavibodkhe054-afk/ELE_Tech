import React from "react";
import { FaCogs, FaBolt, FaIndustry, FaTools } from "react-icons/fa";

const ServicesCards = () => {
  const services = [
    {
      icon: <FaCogs size={22} />,
      title: "Mechanical Utility Piping",
      description:
        "MS, SS, UPVC, CPVC piping with full lifecycle support: design, fabrication, installation, testing, and commissioning. We ensure precision and compliance with industrial standards.",
      iconBg: "bg-gradient-to-tr from-blue-400 to-blue-600 text-white",
    },
    {
      icon: <FaBolt size={22} />,
      title: "Electrical & IT Infrastructure",
      description:
        "Comprehensive electrical systems, structured cabling, CCTV, networking, and scalable IT solutions for factories, offices, and industrial facilities.",
      iconBg: "bg-gradient-to-tr from-orange-400 to-orange-600 text-white",
    },
    {
      icon: <FaIndustry size={22} />,
      title: "Assembly Line Installation",
      description:
        "Installation and optimization of conveyor systems, robotic setups, testing, and commissioning for efficient and automated production lines.",
      iconBg: "bg-gradient-to-tr from-blue-400 to-blue-600 text-white",
    },
    {
      icon: <FaTools size={22} />,
      title: "Spare Parts Procurement",
      description:
        "Reliable sourcing of genuine industrial spare parts with competitive pricing, fast delivery, and quality assurance for uninterrupted operations.",
      iconBg: "bg-gradient-to-tr from-orange-400 to-orange-600 text-white",
    },
  ];

  return (
    <section className="relative bg-gray-50 py-24 overflow-hidden">
      {/* Floating shapes */}
      <div className="absolute -top-20 -left-10 w-72 h-72 bg-blue-300 rounded-full opacity-10 animate-pulseSlow"></div>
      <div className="absolute bottom-10 right-0 w-60 h-60 bg-orange-300 rounded-full opacity-10 animate-pulseSlow delay-500"></div>

      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-gray-800 mb-20">
          What We Do
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {services.map((service, index) => (
            <div
              key={index}
              className="relative bg-white bg-opacity-80 backdrop-blur-md p-8 rounded-3xl shadow-lg hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-500 group overflow-hidden"
            >
              {/* Floating accent circle */}
              <div className="absolute -top-10 -right-10 w-24 h-24 bg-gradient-to-tr from-blue-400 to-purple-400 opacity-20 rounded-full animate-bounceSlow"></div>

              <div
                className={`w-16 h-16 flex items-center justify-center rounded-xl mb-5 ${service.iconBg}`}
              >
                {service.icon}
              </div>
              <h3 className="font-semibold text-xl mb-3 text-gray-800 group-hover:text-blue-600 transition-colors duration-300">
                {service.title}
              </h3>
              <p className="text-gray-600 text-sm md:text-base leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Tailwind Animations */}
      <style jsx>{`
        @keyframes bounceSlow {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-15px); }
        }
        @keyframes pulseSlow {
          0%, 100% { transform: scale(1); opacity: 0.1; }
          50% { transform: scale(1.1); opacity: 0.15; }
        }
        .animate-bounceSlow { animation: bounceSlow 6s ease-in-out infinite; }
        .animate-pulseSlow { animation: pulseSlow 7s ease-in-out infinite; }
        .delay-500 { animation-delay: 0.5s; }
      `}</style>
    </section>
  );
};

export default ServicesCards;
