import React from "react";

const ServicesOverview = () => {
  return (
    <section className="max-w-7xl mx-auto px-6 py-20 grid lg:grid-cols-2 gap-16 items-center">

      <div>
        <h2 className="text-3xl font-bold text-gray-800 mb-6">
          About Our Services
        </h2>

        <p className="text-gray-600 leading-relaxed mb-6">
          Our engineering services are built around quality execution,
          safety standards, and customized engineering approaches tailored
          to each client’s operational requirements.
        </p>

        <p className="text-gray-600 leading-relaxed">
          From system design to commissioning, our team ensures every
          project follows structured planning, technical precision,
          and industry compliance standards.
        </p>
      </div>

      <div className="flex justify-center">
        <img
          src="https://cdn-icons-png.flaticon.com/512/2779/2779775.png"
          alt="engineering"
          className="w-[380px]"
        />
      </div>
    </section>
  );
};

export default ServicesOverview;
