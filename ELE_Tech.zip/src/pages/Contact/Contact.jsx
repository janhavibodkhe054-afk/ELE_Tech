import React from 'react'

import InfoContact from './section/Infocontact';

const Contact = () => {
  return (
    <div>
      <InfoContact />
      

    </div>
  )
}

export default Contact
