import React from 'react'

import InfoContact from './section/InfoContact'

const Contact = () => {
  return (
    <div>
      <InfoContact />
      

    </div>
  )
}

export default Contact
