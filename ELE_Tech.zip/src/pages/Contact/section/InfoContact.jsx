import React from "react";
import {
  FaPhoneAlt,
  FaEnvelope,
  FaMapMarkerAlt,
} from "react-icons/fa";

const Contact = () => {
  return (
    <div className="bg-white">

      {/* ================= HERO SECTION ================= */}
      <section
        className="relative h-[400px] flex items-center justify-center text-center"
        style={{
          backgroundImage:
            "url('https://img.freepik.com/premium-photo/electrical-engineering-drawings-pencil-digital-multimeter_926199-2273854.jpg?semt=ais_wordcount_boost&w=740&q=80')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-black/50"></div>

        <div className="relative z-10 text-white">
          <h1 className="text-5xl font-bold mb-4">Contact</h1>
          <p className="text-lg opacity-90">
            Let’s talk about your next project
          </p>
        </div>
      </section>

      {/* ================= CONTACT SECTION ================= */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-16">

          {/* LEFT CONTENT */}
          <div>
            <p className="text-sm text-blue-600 font-semibold tracking-wide mb-3">
              OUR TEAM
            </p>

            <h2 className="text-4xl font-bold text-gray-800 mb-6">
              Keep in touch
            </h2>

            <p className="text-gray-500 leading-relaxed mb-10">
              We are always ready to support your business requirements.
              Contact us for project discussions, technical consultation,
              or partnership opportunities. Our team will get back to you
              as soon as possible.
            </p>

            {/* CONTACT INFO */}
            <div className="space-y-6">

              <div className="flex gap-4">
                <div className="bg-orange-100 text-orange-500 p-3 rounded-lg">
                  <FaPhoneAlt />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">
                    Contact Person
                  </p>
                  <p className="text-gray-500">Santosh Matkar</p>
                  <p className="text-gray-500">+91 9423444184</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="bg-blue-100 text-blue-600 p-3 rounded-lg">
                  <FaEnvelope />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Email</p>
                  <p className="text-gray-500">
                    santosh.matkar@ele-tech.com
                  </p>
                  <p className="text-gray-500">
                    sales@ele-tech.com
                  </p>
                  <p className="text-gray-500">
                    info@ele-tech.com
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="bg-orange-100 text-orange-500 p-3 rounded-lg">
                  <FaMapMarkerAlt />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Location</p>
                  <p className="text-gray-500">
                    Pune, Maharashtra, India
                  </p>
                </div>
              </div>

              <div className="pt-4">
                <p className="font-semibold text-gray-800 mb-1">
                  Business Hours
                </p>
                <p className="text-gray-500">
                  Monday – Saturday: 9:00 AM – 6:30 PM
                </p>
                <p className="text-gray-500">Sunday: Closed</p>
              </div>
            </div>
          </div>

          {/* RIGHT FORM */}
          <div className="bg-white shadow-xl rounded-2xl p-10 border border-gray-100">
            <form className="space-y-6">

              <input
                type="text"
                placeholder="Your Name"
                className="w-full border-b border-gray-300 py-3 focus:outline-none focus:border-orange-500"
              />

              <input
                type="email"
                placeholder="Email"
                className="w-full border-b border-gray-300 py-3 focus:outline-none focus:border-orange-500"
              />

              <input
                type="text"
                placeholder="Subject"
                className="w-full border-b border-gray-300 py-3 focus:outline-none focus:border-orange-500"
              />

              <textarea
                rows="4"
                placeholder="What are you looking for?"
                className="w-full border-b border-gray-300 py-3 focus:outline-none focus:border-orange-500"
              ></textarea>

              <button
                type="submit"
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-full font-semibold transition mt-24"
              >
                Send Message
              </button>
            </form>
          </div>

        </div>
      </section>

      {/* ================= CONTACT BAR ================= */}
      <section className="bg-gray-50 border-t border-b">
        <div className="max-w-7xl mx-auto px-6 py-10 grid md:grid-cols-3 gap-8 text-center">

          <div>
            <p className="font-semibold text-gray-800">Postal Address</p>
            <p className="text-gray-500 mt-1">
              Pune, Maharashtra, India
            </p>
          </div>

          <div>
            <p className="font-semibold text-gray-800">Email</p>
            <p className="text-gray-500 mt-1">
              info@ele-tech.com
            </p>
          </div>

          <div>
            <p className="font-semibold text-gray-800">Business Phone</p>
            <p className="text-gray-500 mt-1">
              +91 9423444184
            </p>
          </div>

        </div>
      </section>

      {/* ================= MAP SECTION ================= */}
      <section className="h-[420px] w-full">
        <iframe
          title="map"
          src="https://maps.google.com/maps?q=Pune%20Maharashtra&t=&z=11&ie=UTF8&iwloc=&output=embed"
          className="w-full h-full border-0"
          loading="lazy"
        ></iframe>
      </section>
    </div>
  );
};

export default Contact;
